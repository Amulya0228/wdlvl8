console.log("First JS import on EJS application!!");
const name = "Shreedhar";
